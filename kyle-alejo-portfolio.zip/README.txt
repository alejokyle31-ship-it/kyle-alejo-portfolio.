KYLE ALEJO - PERSONAL PORTFOLIO

FILES
- index.html: website content and sections
- style.css: layout, colors, typography, and responsive design
- script.js: mobile navigation and current year

HOW TO VIEW
1. Extract the ZIP file.
2. Keep all three files in the same folder.
3. Open index.html in a web browser.

BEFORE SUBMITTING
1. Update the contact email in index.html.
2. Replace the sample Java code in the Java Code section with your actual CC102 console game.
3. Review your name, school details, and skills.
4. Test every navigation link and check the site on mobile and desktop.

PUBLISH WITH GITHUB PAGES
1. Sign in to GitHub and create a new PUBLIC repository, for example: kyle-alejo-portfolio.
2. Upload index.html, style.css, and script.js to the repository's main branch.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and /(root), then click Save.
6. Wait for GitHub Pages to publish. Your website link will appear in Settings > Pages.
